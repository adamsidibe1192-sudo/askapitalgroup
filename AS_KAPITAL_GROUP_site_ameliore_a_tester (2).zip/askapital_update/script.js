const menuToggle = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");
menuToggle?.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
});
nav?.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  menuToggle?.setAttribute("aria-expanded", "false");
}));
const year = document.getElementById("year");
if (year) year.textContent = new Date().getFullYear();
const form = document.getElementById("quoteForm");
form?.addEventListener("submit", (event) => {
  event.preventDefault();
  const data = new FormData(form);
  const message = [
    "Bonjour AS KAPITAL GROUP,", "",
    "Je souhaite être recontacté(e) au sujet de ma demande.",
    "Nom : " + data.get("fullname"),
    "Téléphone / WhatsApp : " + data.get("phone"),
    "E-mail : " + (data.get("email") || "Non renseigné"),
    "Activité / besoin : " + data.get("insuranceType"),
    "Précisions : " + (data.get("details") || "Non renseignées"), "",
    "J’accepte que mes coordonnées soient utilisées pour répondre à cette demande."
  ].join("\n");
  const whatsappNumber = "22371187396";
  const status = document.getElementById("formStatus");
  if (!whatsappNumber) { if(status) status.textContent = "Le numéro WhatsApp n'est pas configuré."; return; }
  const url = "https://wa.me/" + whatsappNumber + "?text=" + encodeURIComponent(message);
  window.open(url, "_blank", "noopener,noreferrer");
  if(status) status.textContent = "Votre message est prêt dans WhatsApp. Vérifiez-le puis envoyez-le pour finaliser la demande.";
});


// Recherche instantanée dans le catalogue de services (sans rechargement de page).
const catalogSearch = document.getElementById("catalogSearch");
if (catalogSearch) {
  const catalogCards = [...document.querySelectorAll(".catalog-card")];
  const searchStatus = document.getElementById("catalogSearchStatus");
  const updateCatalog = () => {
    const query = catalogSearch.value.trim().toLocaleLowerCase("fr");
    let visible = 0;
    catalogCards.forEach(card => {
      const matches = card.textContent.toLocaleLowerCase("fr").normalize("NFD").replace(/[\u0300-\u036f]/g, "").includes(query.normalize("NFD").replace(/[\u0300-\u036f]/g, ""));
      card.hidden = !matches;
      if (matches) visible++;
    });
    if (searchStatus) searchStatus.textContent = visible ? `${visible} service${visible > 1 ? "s" : ""} affiché${visible > 1 ? "s" : ""}` : "Aucun service trouvé. Essayez un autre mot-clé.";
  };
  catalogSearch.addEventListener("input", updateCatalog);
}
